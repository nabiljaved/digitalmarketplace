 <!-- Page Header -->
 <div class="page-header">
    <div class="row">
        <div class="col-md-4">						
            <div class="provider-subtitle">
                <h6><?php echo e($title); ?></h6>
            </div>
        </div>
        <?php if(!Route::is(['provider-availability','provider-holiday'])): ?>
        <div class="col-md-8 d-flex align-items-center justify-content-md-end flex-wrap">
            <?php if(!Route::is(['provider-payout'])): ?>
            <div class="review-sort me-2">
                <p>Sort</p>
                <?php if(!Route::is(['provider-reviews'])): ?>
                <select class="select">
                    <option>A -> Z</option>
                    <option>Most helful</option>
                </select>
                <?php endif; ?>
                <?php if(Route::is(['provider-reviews'])): ?>
                <select class="select">
                    <option>A -> Z</option>
                    <option>Z -> A</option>
                    <option selected>Most helful</option>
                </select>
                <?php endif; ?>
            </div>
            <?php if(!Route::is(['provider-reviews'])): ?>
            <div class="grid-listview me-2">
                <ul>
                    <li>
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(URL::asset('/assets/img/icons/filter-icon.svg')); ?>" alt="">
                        </a>
                    </li>
                    <?php if(!Route::is(['provider-dashboard','provider-services','provider-coupons','provider-offers','provider-reviews','provider-earnings','provider-services-list'])): ?>
                    <li>
                        <a href="<?php echo e(url('provider-book-details')); ?>" class="<?php echo e(Request::is('provider-book-details') ? 'active' : ''); ?>">
                            <i class="feather-calendar"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('provider-services')); ?>" class="<?php echo e(Request::is('provider-services') ? 'active' : ''); ?>">
                            <i class="feather-grid"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('provider-booking')); ?>" class="<?php echo e(Request::is('provider-booking') ? 'active' : ''); ?>">
                            <i class="feather-list"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(Route::is(['provider-services','provider-services-list'])): ?>
                    <li>
                        <a href="<?php echo e(url('provider-services')); ?>"  class="<?php echo e(Request::is('provider-services') ? 'active' : ''); ?>">
                            <i class="feather-grid"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('provider-services-list')); ?>" class="<?php echo e(Request::is('provider-services-list') ? 'active' : ''); ?>">
                            <i class="feather-list"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(Route::is(['provider-coupons'])): ?>
            <a href="<?php echo e(url('add-coupon')); ?>" class="btn btn-primary add-set"><i class="feather-plus"></i> Add Coupon</a>
            <?php endif; ?>
            <?php if(Route::is(['provider-offers'])): ?>
            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#add-coupon" class="btn btn-primary add-set"><i class="feather-plus"> </i>New Offer</a>
            <?php endif; ?>
            <?php if(Route::is(['provider-services','provider-services-list'])): ?>
            <a href="<?php echo e(url('service-information')); ?>" class="btn btn-primary add-set"><i class="feather-plus me-2"></i>Add Service</a>
            <?php endif; ?>
           
            <?php endif; ?>
            <?php if(Route::is(['provider-payout'])): ?>
            <a href="javascript:;" class="btn btn-primary add-set" data-bs-toggle="modal" data-bs-target="#add-payout"><i class="feather-settings me-2"></i>Set Payout</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if(Route::is(['provider-holiday'])): ?>
        <div class="col-md-8">
            <div class="leave-action text-md-end">
                <a href="javascript:;" class="btn btn-secondary"><i class="feather-file-text"></i> Leave History</a>
                <a href="javascript:;" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#add-holiday"><i class="feather-plus"></i> Add Holiday</a>
                <a href="javascript:;" class="btn btn-primary add-set" data-bs-toggle="modal" data-bs-target="#add-leave"><i class="feather-plus"></i> Add Leave</a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<!-- /Page Header --><?php /**PATH C:\Users\hp\Documents\NabeelJaved\digital-market-place\digital-market-place\trulysell\digital-market-place\resources\views/components/pageheader.blade.php ENDPATH**/ ?>