<div class="bg-img">
    <img src="<?php echo e(URL::asset('/assets/img/bg/work-bg-03.png')); ?>" alt="img" class="bgimg1">
    <img src="<?php echo e(URL::asset('/assets/img/bg/work-bg-03.png')); ?>" alt="img" class="bgimg2">
    <?php if(!Route::is(['categories','pricing','maintenance','coming-soon','privacy-policy','terms-condition'])): ?>
    <img src="<?php echo e(URL::asset('/assets/img/bg/feature-bg-03.png')); ?>" alt="img" class="bgimg3">
    <?php endif; ?>
    <?php if(Route::is(['faq'])): ?>
    <img src="<?php echo e(URL::asset('/assets/img/bg/about-bg-01.png')); ?>" alt="img" class="bgimg4 img-fluid">
    <?php endif; ?>
</div><?php /**PATH C:\Users\hp\Documents\NabeelJaved\digital-market-place\digital-market-place\trulysell\digital-market-place\resources\views/components/backgroundimage.blade.php ENDPATH**/ ?>