<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layout.partials.head_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="main-wrapper">
        <?php if(
            !Route::is([
                'wallet-history',
                'change-password',
                'device-management',
                'login-activity',
                'facebook-api',
                'google-api',
                'php-mail',
                'smtp',
                'nexmo',
                'paypal',
                'aws-storage',
                'signin',
                'forget-password',
                'signup',
            ])): ?>
            <?php echo $__env->make('layout.partials.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('layout.partials.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php if(Route::is(['index_admin'])): ?>
    <div id="overlayer">
        <span class="loader">
        <span class="loader-inner"></span>
        </span>
    </div>
    <?php endif; ?>

    <?php echo $__env->make('layout.partials.footer_admin-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\hp\Documents\NabeelJaved\digital-market-place\digital-market-place\trulysell\digital-market-place\resources\views/layout/mainlayout_admin.blade.php ENDPATH**/ ?>