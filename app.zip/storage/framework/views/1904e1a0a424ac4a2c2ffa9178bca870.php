<div class="content-page-header">
    <h5><?php echo e($addtitle); ?></h5>
</div>
<?php /**PATH C:\Users\hp\Documents\NabeelJaved\digital-market-place\digital-market-place\trulysell\digital-market-place\resources\views/admin/components/addpageheader.blade.php ENDPATH**/ ?>