<!-- Breadcrumb -->
<?php if(!Route::is(['invoice'])): ?>
<div class="breadcrumb-bar">
    <div class="container">
        <div class="row">
            <?php if(!Route::is(['providers','provider-details'])): ?>
            <div class="col-md-12 col-12">
                <h2 class="breadcrumb-title"><?php echo e($title); ?></h2>
                <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e($li_1); ?></a></li>
                        <?php if(Route::is(['blog-grid','blog-list','blog-details'])): ?>
                        <li class="breadcrumb-item" aria-current="page"><?php echo e($li_3); ?></li>
                        <?php endif; ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($li_2); ?></li>
                    </ol>
                </nav>
            </div>
            <?php endif; ?>
            <?php if(Route::is(['providers','provider-details'])): ?>
            <div class="col-md-12">
                <h2 class="breadcrumb-title mb-0"><?php echo e($title); ?></h2>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if(Route::is(['invoice'])): ?>
<div class="page-topbar">
    <div class="row align-items-center">
        <div class="col-md-12">
            <div class="back-link">
                <a href="<?php echo e(url('/')); ?>"><i class="fa-solid fa-arrow-left-long me-1"></i> Back</a>
            </div>
            <div class="breadcrumb invoice-breadcrumb">
                <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">Orders</li>
                        <li class="breadcrumb-item" aria-current="page">ID 2378910</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<!-- /Breadcrumb --><?php /**PATH C:\Users\hp\Documents\NabeelJaved\digital-market-place\digital-market-place\trulysell\digital-market-place\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>