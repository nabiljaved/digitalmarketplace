<div class="row">
    <div class="col-12">
        <div class="tab-sets">
            <div class="tab-contents-sets">
                <?php if(Route::is(['services', 'pending-services', 'deleted-services', 'inactive-services'])): ?>
                    <ul>
                        <li>
                            <a class="<?php echo e(Request::is('admin/services') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/services')); ?>">All Services</a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/pending-services') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/pending-services')); ?>">Pending Services</a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/deleted-services') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/deleted-services')); ?>">Deleted Services</a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/inactive-services') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/inactive-services')); ?>">Inactive Services</a>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php if(Route::is(['booking', 'pending-booking', 'inprogress-booking', 'completed-booking', 'cancelled-booking'])): ?>
                    <ul>
                        <li>
                            <a class="<?php echo e(Request::is('admin/booking') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/booking')); ?>">All Booking</a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/pending-booking') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/pending-booking')); ?>">Pending </a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/inprogress-booking') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/inprogress-booking')); ?>">Inprogress </a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/completed-booking') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/completed-booking')); ?>">Completed </a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('admin/cancelled-booking') ? 'active' : ''); ?>"
                                href="<?php echo e(url('admin/cancelled-booking')); ?>">Cancelled</a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
            <?php if(Route::is([
                    'services',
                    'pending-services',
                    'deleted-services',
                    'inactive-services',
                    'booking',
                    'pending-booking',
                    'inprogress-booking',
                    'completed-booking',
                    'cancelled-booking',
                ])): ?>
                <div class="tab-contents-count">
                    <h6>Showing 8-10 of 84 results</h6>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php /**PATH C:\Users\hp\Documents\NabeelJaved\digital-market-place\digital-market-place\trulysell\digital-market-place\resources\views/admin/components/tabsets.blade.php ENDPATH**/ ?>